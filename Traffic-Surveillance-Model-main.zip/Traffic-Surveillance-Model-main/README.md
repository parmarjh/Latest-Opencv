# Traffic-Surveillance-Model
In this project, **Euclidean_distance based tracker** and Deep Learning algorithm are used.

About surveillance.py
* It supports HD .mp4 extension video source for inference
* It only detects, tracks, and counts four vehicle classes i.e. car, motorbike, bus, and truck

# Reference
https://techvidvan.com/tutorials/opencv-vehicle-detection-classification-counting/