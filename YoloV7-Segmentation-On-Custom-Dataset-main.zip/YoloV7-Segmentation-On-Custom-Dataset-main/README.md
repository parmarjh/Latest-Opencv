![Yolov7 Segmentation on Crack using Roboflow dataset](https://user-images.githubusercontent.com/85284912/190906601-f914a38d-e337-49c3-aba7-5bd3587dad4b.png)

