# Serial-Killers

 CURIOSIDADES SOBRE LOS ASESINOS EN SERIE MÁS FAMOSOS!!😱😱😱
 
 ![image](https://user-images.githubusercontent.com/89918661/189140872-df549fc2-73bc-41ab-9698-c6b6c026c7d9.png)

 
¿Cuáles son los signos del zodiaco más peligrosos? Te muestro la respuesta 🤡
