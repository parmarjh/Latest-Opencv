from django.contrib import admin
from .models import BasketItem

# Register your models here.
admin.site.register(BasketItem)
