MIS PROYECTOS NLP🎬

Es entretenido unir los datos con la creatividad🎨.Analizar tus canciones favoritas, libros, poemas, nunca había sido tan matemático.
En estos proyectos nos olvidamos de los gráficos de barras, líneas, tartas, entre otros, creando imágenes que representen resultados 🎭.

![image](https://user-images.githubusercontent.com/89918661/189141665-0e9370cb-e6ea-4f9b-b757-0e173bf6a7da.png)

